
from flask import Flask, render_template, request, session, redirect, url_for
from openai import OpenAI
from models import debug_all_applications
import sqlite3


from models import (
    init_db,
    add_application,
    get_all_applications,
    get_user_applications,
    get_stats,
    register_user,
    login_user,
    create_sales_manager
)

app = Flask(__name__)
app = Flask(__name__)

client = OpenAI()

app.secret_key = "loan_approval_secret_key"

# Secret key for sessions
app.secret_key = "loan_approval_secret_key"


# ==================================================
# LOAN RULES
# ==================================================

MIN_CREDIT_SCORE = 650
MAX_EMI_TO_INCOME_RATIO = 0.40
MAX_LOAN_TO_INCOME_MULTIPLE = 10


# ==================================================
# INTEREST RATE BASED ON CREDIT SCORE
# ==================================================

def get_interest_rate(credit_score):

    if credit_score >= 750:
        return 0.08

    elif credit_score >= 700:
        return 0.09

    elif credit_score >= 650:
        return 0.10

    else:
        return None


# ==================================================
# EMI CALCULATION
# ==================================================

def calculate_emi(
    loan_amount,
    loan_term_months,
    annual_rate
):

    monthly_rate = annual_rate / 12

    if monthly_rate == 0:

        return round(
            loan_amount / loan_term_months,
            2
        )

    factor = (
        (1 + monthly_rate)
        ** loan_term_months
    )

    emi = (
        loan_amount
        * monthly_rate
        * factor
    ) / (factor - 1)

    return round(emi, 2)


# ==================================================
# LOAN ELIGIBILITY
# ==================================================

def check_eligibility(
    income,
    credit_score,
    loan_amount,
    loan_term_months,
    employment_type
):

    reasons = []

    # Annual income -> monthly income
    monthly_income = income / 12

    # Interest rate
    interest_rate = get_interest_rate(
        credit_score
    )

    # --------------------------------------------------
    # CREDIT SCORE CHECK
    # --------------------------------------------------

    if credit_score < MIN_CREDIT_SCORE:

        reasons.append(
            f"Credit score {credit_score} is below "
            f"the minimum required "
            f"({MIN_CREDIT_SCORE})."
        )

        return (
            "Rejected",
            reasons,
            None,
            None
        )

    # --------------------------------------------------
    # EMI CALCULATION
    # --------------------------------------------------

    emi = calculate_emi(
        loan_amount,
        loan_term_months,
        interest_rate
    )

    # --------------------------------------------------
    # EMI TO INCOME CHECK
    # --------------------------------------------------

    maximum_allowed_emi = (
        MAX_EMI_TO_INCOME_RATIO
        * monthly_income
    )

    if emi > maximum_allowed_emi:

        reasons.append(
            f"Estimated EMI of ₹{emi:,.2f} "
            f"exceeds "
            f"{int(MAX_EMI_TO_INCOME_RATIO * 100)}% "
            f"of monthly income "
            f"(₹{monthly_income:,.2f})."
        )

    # --------------------------------------------------
    # LOAN TO INCOME CHECK
    # --------------------------------------------------

    if loan_amount > (
        MAX_LOAN_TO_INCOME_MULTIPLE
        * income
    ):

        reasons.append(
            f"Loan amount exceeds "
            f"{MAX_LOAN_TO_INCOME_MULTIPLE}x "
            f"annual income."
        )

    # --------------------------------------------------
    # EMPLOYMENT CHECK
    # --------------------------------------------------

    if employment_type.lower() == "unemployed":

        reasons.append(
            "Applicant is currently unemployed."
        )

    # --------------------------------------------------
    # FINAL DECISION
    # --------------------------------------------------

    if reasons:

        return (
            "Rejected",
            reasons,
            interest_rate,
            emi
        )

    return (
        "Approved",
        [
            "Meets all eligibility criteria.",
            f"Interest Rate: "
            f"{interest_rate * 100:.2f}%",
            f"Estimated EMI: "
            f"₹{emi:,.2f}"
        ],
        interest_rate,
        emi
    )


# ==================================================
# HOME / LOGIN PAGE
# ==================================================

@app.route("/")
def index():

    return render_template(
        "login.html"
    )


# ==================================================
# LOGIN
# ==================================================

@app.route(
    "/login",
    methods=["GET", "POST"]
)
def login():

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]

        user = login_user(
            email,
            password
        )

        if user:

            session["user_id"] = user["id"]
            session["email"] = user["email"]
            session["role"] = user["role"]
            session["name"] = user["name"]

            # Sales Manager
            if user["role"] == "sales_manager":

                return redirect(
                    url_for("admin")
                )

            # Employee
            return redirect(
                url_for("employee_dashboard")
            )

        return render_template(
            "login.html",
            error="Invalid Email or Password"
        )

    return render_template(
        "login.html"
    )


# ==================================================
# LOAN APPLICATION FORM
# ==================================================

@app.route("/loan")
def loan_form():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    if session.get("role") == "sales_manager":

        return redirect(
            url_for("admin")
        )

    return render_template(
        "form.html"
    )


# ==================================================
# LOAN APPLICATION
# ==================================================

@app.route(
    "/apply",
    methods=["POST"]
)
def apply():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )
    # --------------------------------------------------
    # GET FORM VALUES
    # --------------------------------------------------
    name = request.form[
        "name"
    ].strip()

    income = float(
        request.form["income"]
    )

    credit_score = int(
        request.form["credit_score"]
    )

    loan_amount = float(
        request.form["loan_amount"]
    )

    loan_term = int(
        request.form["loan_term"]
    )

    employment_type = request.form[
        "employment_type"
    ]
    # --------------------------------------------------
    # CHECK ELIGIBILITY
    # --------------------------------------------------

    (
        status,
        reasons,
        interest_rate,
        emi
    ) = check_eligibility(
        income,
        credit_score,
        loan_amount,
        loan_term,
        employment_type
    )
    # --------------------------------------------------
    # TOTAL PAYMENT
    # --------------------------------------------------

    if emi is not None:

        total_payment = (
            emi * loan_term
        )

        total_interest = (
            total_payment
            - loan_amount
        )

    else:

        total_payment = None
        total_interest = None
    # --------------------------------------------------
    # EMI / INCOME RATIO
    # --------------------------------------------------

    monthly_income = income / 12

    if (
        emi is not None
        and monthly_income > 0
    ):

        emi_income_ratio = (
            emi / monthly_income
        ) * 100

    else:

        emi_income_ratio = None

    # --------------------------------------------------
    # CREDIT SCORE CATEGORY
    # --------------------------------------------------

    if credit_score >= 750:

        credit_category = "Excellent"

    elif credit_score >= 700:

        credit_category = "Good"

    elif credit_score >= 650:

        credit_category = "Average"

    else:

        credit_category = "Poor"
    # --------------------------------------------------
    # SAVE APPLICATION
    # --------------------------------------------------

    add_application(
        name,
        income,
        credit_score,
        loan_amount,
        loan_term,
        employment_type,
        gender,
        property_area,
        status,
        "; ".join(reasons)
    )
    # --------------------------------------------------
    # SHOW RESULT
    # --------------------------------------------------

    return render_template(
        "form.html",

        result={

            "status": status,

            "credit_score": credit_score,

            "credit_category": credit_category,

            "interest_rate": (

                interest_rate * 100

                if interest_rate is not None

                else None
            ),

            "emi": (

                round(emi, 2)

                if emi is not None

                else None
            ),

            "total_payment": (

                round(
                    total_payment,
                    2
                )

                if total_payment is not None

                else None
            ),

            "total_interest": (

                round(
                    total_interest,
                    2
                )

                if total_interest is not None

                else None
            ),

            "emi_income_ratio": (

                round(
                    emi_income_ratio,
                    2
                )

                if emi_income_ratio is not None

                else None
            ),

            "reasons": reasons
        }
    )
# ==================================================
# APPLICATION HISTORY
# ==================================================
# ==================================================
# APPLICATION HISTORY
# ==================================================

@app.route("/history")
def history():

    if "user_id" not in session:
        return redirect(url_for("login"))

    # Get selected filter
    status = request.args.get("status")

    # --------------------------------------------------
    # EMPLOYEE
    # --------------------------------------------------

    if session.get("role") == "employee":

        applications = get_user_applications(
            session.get("name"),
            status
        )

        return render_template(
            "history.html",
            applications=applications,
            active_status=status
        )

    # --------------------------------------------------
    # SALES MANAGER
    # --------------------------------------------------

    if session.get("role") == "sales_manager":

        applications = get_all_applications(status)

        return render_template(
            "history.html",
            applications=applications,
            active_status=status
        )

    return "Access Denied", 403
    
# ==================================================
# ADMIN DASHBOARD
# ONLY SALES MANAGER
# ==================================================

@app.route("/admin")
def admin():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    if session.get("role") != "sales_manager":

        return """
        <h2>Access Denied</h2>

        <p>
            Only Sales Managers can access
            the Admin Dashboard.
        </p>

        <a href="/employee-dashboard">
            Go to Employee Dashboard
        </a>
        """

    stats = get_stats()

    applications = get_all_applications()

    return render_template(
        "admin.html",
        stats=stats,
        applications=applications
    )
# ==================================================
# REGISTER
# ==================================================
@app.route(
    "/register",
    methods=["GET", "POST"]
)
def register():

    if request.method == "POST":

        name = request.form["name"]

        email = request.form["email"]

        password = request.form["password"]

        try:

            register_user(
                name,
                email,
                password
            )

            return render_template(
                "login.html",
                success=(
                    "Registration Successful. "
                    "Please Login."
                )
            )

        except sqlite3.IntegrityError:

            return render_template(
                "register.html",
                error="Email already exists."
            )

    return render_template(
        "register.html"
    )
# ==================================================
# LOGOUT
# ==================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect(
        url_for("login")
    )
# ==================================================
# EMPLOYEE DASHBOARD
# ==================================================
@app.route("/employee-dashboard")
def employee_dashboard():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    if session.get("role") != "employee":

        return "Access Denied", 403

    return render_template(
        "employee_dashboard.html",
        name=session.get("name")
    )


# ==================================================
# ELIGIBILITY PAGE
# ==================================================

@app.route("/eligibility")
def eligibility():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    if session.get("role") != "employee":

        return "Access Denied", 403

    return render_template(
        "eligibility.html"
    )
# ==================================================
# CHECK ELIGIBILITY
# ==================================================
@app.route(
    "/check-eligibility",
    methods=["POST"]
)
def eligibility_result():

    if "user_id" not in session:
        return redirect(
            url_for("login")
        )

    if session.get("role") != "employee":
        return "Access Denied", 403

    # --------------------------------------------------
    # GET FORM VALUES
    # --------------------------------------------------

    # Use the logged-in user's name
    name = session.get("name")

    income = float(
        request.form["income"]
    )

    credit_score = int(
        request.form["credit_score"]
    )

    loan_amount = float(
        request.form["loan_amount"]
    )

    loan_term = int(
        request.form["loan_term"]
    )

    employment_type = request.form[
        "employment_type"
    ]

    gender = request.form[
        "gender"
    ]

    property_area = request.form[
        "property_area"
    ]

    # --------------------------------------------------
    # CHECK ELIGIBILITY
    # --------------------------------------------------

    (
        status,
        reasons,
        interest_rate,
        emi
    ) = check_eligibility(
        income,
        credit_score,
        loan_amount,
        loan_term,
        employment_type
    )
# --------------------------------------------------

# Always use the name of the logged-in employee
       # GET FORM VALUES
# --------------------------------------------------

    # --------------------------------------------------
    ## TOTAL PAYMENT
    # --------------------------------------------------

    if emi is not None:

        total_payment = (
            emi * loan_term
        )

        total_interest = (
            total_payment
            - loan_amount
        )

    else:

        total_payment = None
        total_interest = None

    # --------------------------------------------------
    # EMI / INCOME RATIO
    # --------------------------------------------------

    monthly_income = income / 12

    if (
        emi is not None
        and monthly_income > 0
    ):

        emi_income_ratio = (
            emi / monthly_income
        ) * 100

    else:

        emi_income_ratio = None
    # --------------------------------------------------
    # CREDIT CATEGORY
    # --------------------------------------------------

    if credit_score >= 750:

        credit_category = "Excellent"

    elif credit_score >= 700:

        credit_category = "Good"

    elif credit_score >= 650:

        credit_category = "Average"

    else:

        credit_category = "Poor"
    # --------------------------------------------------
    # SAVE APPLICATION
    # --------------------------------------------------

    add_application(
        name,
        income,
        credit_score,
        loan_amount,
        loan_term,
        employment_type,
        gender,
        property_area,
        status,
        "; ".join(reasons)
        
    )
    # --------------------------------------------------
    # SHOW RESULT
    # --------------------------------------------------

    return render_template(
        "result.html",

        name=name,

        income=income,

        credit_score=credit_score,

        credit_category=credit_category,

        loan_amount=loan_amount,

        loan_term=loan_term,

        employment_type=employment_type,

        gender=gender,

        property_area=property_area,

        status=status,

        reasons=reasons,

        interest_rate=(
            interest_rate * 100
            if interest_rate is not None
            else None
        ),

        emi=(
            round(emi, 2)
            if emi is not None
            else None
        ),

        total_payment=(
            round(total_payment, 2)
            if total_payment is not None
            else None
        ),

        total_interest=(
            round(total_interest, 2)
            if total_interest is not None
            else None
        ),

        emi_income_ratio=(
            round(emi_income_ratio, 2)
            if emi_income_ratio is not None
            else None
        )
    )
# ==================================================
# LOAN STATUS
# ==================================================
@app.route("/loan-status")
def loan_status():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )
    if session.get("role") != "employee":

        return "Access Denied", 403
    applications = get_user_applications(
        session.get("name")
    )
    return render_template(
        "loan_status.html",
        applications=applications
    )
# ==================================================
# EMI CALCULATOR
# ==================================================
@app.route(
    "/emi",
    methods=["GET", "POST"]
)
def emi():
    if "user_id" not in session:

        return redirect(
            url_for("login")
        )
    if session.get("role") != "employee":
        return "Access Denied", 403
    result = None
    if request.method == "POST":
        loan_amount = float(
            request.form["loan_amount"]
        )

        loan_term = int(
            request.form["loan_term"]
        )
        interest_rate = float(
            request.form["interest_rate"]
        )
        annual_rate = (
            interest_rate / 100
        )
        result = calculate_emi(
            loan_amount,
            loan_term,
            annual_rate
        )
    return render_template(
        "emi.html",
        result=result
    )
    # ==================================================
# AI LOAN ASSISTANT
# ==================================================

@app.route("/ai-assistant", methods=["GET", "POST"])
def ai_assistant():

    if "user_id" not in session:
        return redirect(url_for("login"))

    if session.get("role") != "employee":
        return "Access Denied", 403

    answer = None

    if request.method == "POST":

        question = request.form["question"].strip()

        if question:

            response = client.responses.create(
                model="gpt-5.6",
                input=f"""
You are an AI assistant for a Loan Management System.

Answer the user's question clearly and simply.

You can explain:
- Loan eligibility
- Credit score
- EMI
- Interest rate
- Loan amount
- Loan tenure
- Income
- Reasons for loan rejection
- General loan questions

Do not make the actual loan approval or rejection decision.
The application's fixed eligibility rules make that decision.

User question:
{question}
"""
            )

            answer = response.output_text

    return render_template(
        "ai_assistant.html",
        answer=answer
    )

    
if __name__ == "__main__":
    init_db()
    create_sales_manager()
    app.run(debug=True)
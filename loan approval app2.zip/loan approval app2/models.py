
import sqlite3

DB_PATH = "loans.db"


# ==================================================
# DATABASE CONNECTION
# ==================================================
def get_connection():
    conn = sqlite3.connect(DB_PATH)

    conn.row_factory = sqlite3.Row

    return conn
# ==================================================
# INITIALIZE DATABASE
# ==================================================

def init_db():

    conn = get_connection()

    # --------------------------------------------------
    # LOAN APPLICATION TABLE
    # --------------------------------------------------

    conn.execute("""
        CREATE TABLE IF NOT EXISTS loan_application (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            income REAL NOT NULL,
            credit_score INTEGER NOT NULL,
            loan_amount REAL NOT NULL,
            loan_term INTEGER NOT NULL,
            employment_type TEXT NOT NULL,
            gender TEXT,
             property_area TEXT,

            status TEXT NOT NULL,
            reason TEXT
        )
    """)
    
        # --------------------------------------------------
    # UPDATE OLD LOAN DATABASE
    # --------------------------------------------------

    try:
        conn.execute(
            "ALTER TABLE loan_application ADD COLUMN gender TEXT"
        )
    except sqlite3.OperationalError:
        pass

    try:
        conn.execute(
            "ALTER TABLE loan_application ADD COLUMN property_area TEXT"
        )
    except sqlite3.OperationalError:
        pass

    try:
        conn.execute(
            "ALTER TABLE loan_application ADD COLUMN status TEXT"
        )
    except sqlite3.OperationalError:
        pass

    try:
        conn.execute(
            "ALTER TABLE loan_application ADD COLUMN reason TEXT"
        )
    except sqlite3.OperationalError:
        pass


    conn.commit()

    # --------------------------------------------------
    # USERS TABLE
    # --------------------------------------------------

    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user'
        )
    """)

    # --------------------------------------------------
    # ADD ROLE COLUMN TO OLD DATABASE
    # --------------------------------------------------

    try:

        conn.execute(
            "ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'user'"
        )

        conn.commit()

    except sqlite3.OperationalError:

        # Column already exists
        pass
    conn.execute("""
    UPDATE users
    SET role = 'employee'
    WHERE role = 'user'
""")

    conn.commit()

    conn.close()


# ==================================================
# ADD LOAN APPLICATION
# ==================================================
def add_application(
    name,
    income,
    credit_score,
    loan_amount,
    loan_term,
    employment_type,
    gender,
    property_area,
    status,
    reason
):
    conn = get_connection()

    conn.execute(
        """
        INSERT INTO loan_application
        (
            name,
            income,
            credit_score,
            loan_amount,
            loan_term,
            employment_type,
            gender,
            property_area,
            
            status,
            reason
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?,?,?)
        """,
        (
            name,
            income,
            credit_score,
            loan_amount,
            loan_term,
            employment_type,
            gender,
            property_area,
            
            status,
            reason
        )
    )

    conn.commit()

    conn.close()


# ==================================================
# GET ALL APPLICATIONS
# ==================================================

def get_all_applications(status=None):

    conn = get_connection()

    if status in ("Approved", "Rejected"):

        rows = conn.execute(
            """
            SELECT *
            FROM loan_application
            WHERE status = ?
            ORDER BY id DESC
            """,
            (status,)
        ).fetchall()

    else:

        rows = conn.execute(
            """
            SELECT *
            FROM loan_application
            ORDER BY id DESC
            """
        ).fetchall()

    conn.close()

    return rows
# ==================================================
# GET APPLICATIONS FOR CURRENT EMPLOYEE
# ==================================================
# ==================================================
# GET APPLICATIONS FOR CURRENT EMPLOYEE
# ==================================================

def get_user_applications(user_name, status=None):

    conn = get_connection()

    if status in ("Approved", "Rejected"):

        rows = conn.execute(
            """
            SELECT *
            FROM loan_application
            WHERE LOWER(TRIM(name)) = LOWER(TRIM(?))
            AND status = ?
            ORDER BY id DESC
            """,
            (user_name, status)
        ).fetchall()

    else:

        rows = conn.execute(
            """
            SELECT *
            FROM loan_application
            WHERE LOWER(TRIM(name)) = LOWER(TRIM(?))
            ORDER BY id DESC
            """,
            (user_name,)
        ).fetchall()

    conn.close()

    return rows






def debug_all_applications():
    conn = get_connection()

    rows = conn.execute("""
        SELECT id, name, status
        FROM loan_application
        ORDER BY id DESC
    """).fetchall()

    conn.close()

    return rows



# ==================================================
# ADMIN DASHBOARD STATISTICS
# ==================================================

def get_stats():

    conn = get_connection()

    total = conn.execute(
        """
        SELECT COUNT(*) AS c
        FROM loan_application
        """
    ).fetchone()["c"]

    approved = conn.execute(
        """
        SELECT COUNT(*) AS c
        FROM loan_application
        WHERE status = 'Approved'
        """
    ).fetchone()["c"]

    rejected = conn.execute(
        """
        SELECT COUNT(*) AS c
        FROM loan_application
        WHERE status = 'Rejected'
        """
    ).fetchone()["c"]

    # --------------------------------------------------
    # AVERAGE FUNCTION
    # --------------------------------------------------

    def avg_for(status, column):

        row = conn.execute(
            f"""
            SELECT AVG({column}) AS a
            FROM loan_application
            WHERE status = ?
            """,
            (status,)
        ).fetchone()

        if row["a"] is not None:

            return round(
                row["a"],
                2
            )

        return 0

    # --------------------------------------------------
    # STATISTICS
    # --------------------------------------------------

    stats = {

        "total": total,

        "approved": approved,

        "rejected": rejected,

        "approval_rate": (
            round(
                (approved / total) * 100,
                1
            )
            if total
            else 0
        ),

        "avg_credit_approved":
            avg_for(
                "Approved",
                "credit_score"
            ),

        "avg_credit_rejected":
            avg_for(
                "Rejected",
                "credit_score"
            ),

        "avg_loan_approved":
            avg_for(
                "Approved",
                "loan_amount"
            ),

        "avg_loan_rejected":
            avg_for(
                "Rejected",
                "loan_amount"
            )
    }

    conn.close()

    return stats


# ==================================================
# REGISTER USER
# ==================================================

def register_user(
    name,
    email,
    password,
    role="employee"
):

    conn = get_connection()

    conn.execute(
        """
        INSERT INTO users
        (
            name,
            email,
            password,
            role
        )
        VALUES (?, ?, ?, ?)
        """,
        (
            name,
            email,
            password,
            role
        )
    )
    conn.commit()
    conn.close()
# ==================================================
# LOGIN USER
# ==================================================

def login_user(
    email,
    password
):

    conn = get_connection()

    user = conn.execute(
        """
        SELECT *
        FROM users
        WHERE email = ?
        AND password = ?
        """,
        (
            email,
            password
        )
    ).fetchone()

    conn.close()
    return user
# ==================================================
# CREATE SALES MANAGER
# ==================================================
def create_sales_manager():

    conn = get_connection()
    conn.execute(
        """
        INSERT OR IGNORE INTO users
        (
            name,
            email,
            password,
            role
        )
        VALUES (?, ?, ?, ?)
        """,
        (
            "Sales Manager",
            "manager@loan.com",
            "manager123",
            "sales_manager"
        )
    )
    conn.commit()
    conn.close()
    
# Loan Approval Web App

A simple Flask web application that takes a loan applicant's details and
returns an Approved/Rejected decision using rule-based eligibility checks.

## Setup

1. Create and activate a virtual environment:
   ```
   python -m venv venv
   venv\Scripts\activate      (Windows)
   source venv/bin/activate   (Mac/Linux)
   ```
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Run the app:
   ```
   python app.py
   ```
4. Open http://localhost:5000 in your browser.

## Eligibility rules (in app.py)

- Credit score must be at least 650.
- Estimated EMI (assuming 10% annual interest) must not exceed 40% of
  monthly income.
- Loan amount must not exceed 10x annual income.
- Applicant must not be unemployed.

Adjust the constants at the top of `app.py` to change these thresholds.

## Project structure

```
loan-approval-app/
├── app.py            # Routes and eligibility logic
├── models.py         # SQLite database helper functions
├── requirements.txt
├── templates/
│   ├── form.html     # Application form
│   ├── result.html   # Approval/rejection result
│   └── history.html  # Table of past applications
└── static/
    └── style.css
```

Data is stored in `loans.db` (SQLite), created automatically on first run.

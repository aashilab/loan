
import sqlite3

conn = sqlite3.connect("loans.db")

conn.execute("DELETE FROM loan_application")

# Reset the auto-increment counter
conn.execute("DELETE FROM sqlite_sequence WHERE name='loan_application'")

conn.commit()
conn.close()

print("All old loan applications deleted.")
print("Application IDs will now start from 1.")